from pathlib import Path
import pandas as pd


BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"


def load_produksi():
    file_path = DATA_DIR / "Produksi_padi_all.xlsx"

    if not file_path.exists():
        raise FileNotFoundError(
            f"File produksi tidak ditemukan: {file_path}"
        )

    return pd.read_excel(file_path)


def load_konsumsi():
    file_path = DATA_DIR / "Konsumsi Beras, 2018.csv"

    if not file_path.exists():
        raise FileNotFoundError(
            f"File konsumsi tidak ditemukan: {file_path}"
        )


    df = pd.read_csv(
        file_path,
        skiprows=2,
        header=None,
        names=[
            "region",
            "konsumsi"
        ]
    )

    return df