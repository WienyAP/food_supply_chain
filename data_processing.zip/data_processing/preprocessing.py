import pandas as pd


PRODUKSI_COLUMNS = {
    "No": "no",
    "Tahun": "year",
    "Kabupaten/Kota": "region",
    "Luas Panen Tanaman Padi (ha) (Ha)": "luas_panen",
    "Produktivitas Tanaman Padi (ku/ha) (Ku/ha)": "produktivitas",
    "Rekap Produksi Padi (ton) (Ton)": "produksi",
}


def preprocess_produksi(df: pd.DataFrame) -> pd.DataFrame:

    df = df.copy()

    df = df.rename(columns=PRODUKSI_COLUMNS)

    df["region"] = (
        df["region"]
        .astype(str)
        .str.strip()
    )

    numeric_columns = [
        "year",
        "luas_panen",
        "produktivitas",
        "produksi",
    ]

    for column in numeric_columns:
        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )

    missing = df[numeric_columns].isna().sum()

    if missing.any():
        raise ValueError(
            f"Terdapat missing value:\n{missing}"
        )

    duplicate = df.duplicated(
        subset=["year", "region"]
    )

    if duplicate.any():
        raise ValueError(
            "Terdapat duplikasi year + region."
        )

    return df