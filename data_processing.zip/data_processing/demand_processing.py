import pandas as pd


def preprocess_konsumsi(df: pd.DataFrame):

    df = df.copy()

    # =========================================================
    # 1. BERSIHKAN NAMA WILAYAH
    # =========================================================

    df["region"] = (
        df["region"]
        .astype(str)
        .str.strip()
    )

    # =========================================================
    # 2. KONVERSI KONSUMSI KE NUMERIK
    # =========================================================

    df["konsumsi"] = pd.to_numeric(
        df["konsumsi"],
        errors="coerce"
    )

    # =========================================================
    # 3. HAPUS BARIS TIDAK VALID
    # =========================================================

    df = df.dropna(
        subset=["region", "konsumsi"]
    ).copy()

    # =========================================================
    # 4. NORMALISASI NAMA WILAYAH
    # =========================================================

    df["region"] = (
        df["region"]
        .astype(str)
        .str.strip()
)

    # =========================================================
    # 5. PISAHKAN JAWA TIMUR
    # =========================================================

    df_provinsi = df[
        df["region"].str.lower() == "jawa timur"
    ].copy()

    # =========================================================
    # 6. AMBIL HANYA KABUPATEN/KOTA
    # =========================================================

    df_wilayah = df[
        df["region"].str.lower() != "jawa timur"
    ].copy()

    # =========================================================
    # 7. VALIDASI
    # =========================================================

    if df_wilayah["region"].duplicated().any():

        duplicate_regions = (
            df_wilayah.loc[
                df_wilayah["region"].duplicated(),
                "region"
            ]
            .tolist()
        )

        raise ValueError(
            f"Terdapat duplikasi wilayah: "
            f"{duplicate_regions}"
        )

    if (df_wilayah["konsumsi"] < 0).any():

        raise ValueError(
            "Ditemukan nilai konsumsi negatif."
        )

    # =========================================================
    # 8. RESET INDEX
    # =========================================================

    df_wilayah = (
        df_wilayah
        .reset_index(drop=True)
    )

    df_provinsi = (
        df_provinsi
        .reset_index(drop=True)
    )

    # =========================================================
    # 9. RETURN DUA DATAFRAME
    # =========================================================

    return df_wilayah, df_provinsi