import pandas as pd

from .base_agent import BaseAgent


class DemandAgent(BaseAgent):

    def __init__(self):
        super().__init__("Demand Agent")

    def run(self, data: pd.DataFrame) -> pd.DataFrame:

        #=================
        # 1. VALIDASI INPUT
        #======================
        
        required_columns = [
            "region",
            "konsumsi"
        ]

        missing_columns = [
            col
            for col in required_columns
            if col not in data.columns
        ]

        if missing_columns:
            raise ValueError(
                f"Kolom yang diperlukan tidak ditemukan: "
                f"{missing_columns}"
            )

        result = data[
            required_columns
        ].copy()


        #==============
        # 2. VALIDASI DATA
        #===============

        if result.isna().any().any():
            raise ValueError(
                "Terdapat missing value pada data demand"
            )

        if (result["konsumsi"] < 0).any():
            raise ValueError(
                "Terdapat duplikasi wilayah pada data demand"
            )


        #=================
        # 3. CURRENT DEMAND
        #================

        result["current_demand"] = result["konsumsi"]

        #============
        # 4. DEMAND SHARE
        #===============

        total_demand = result["konsumsi"].sum()

        result["demand_share"] = (
            result["konsumsi"] / total_demand
        )

        #==============
        # 5. DEMAND STATUS
        #=============

        median_demand = result["konsumsi"].median()

        result["demand_status"] = result[
            "konsumsi"
        ].apply(
            lambda x:
                "high" if x >= median_demand
                else "low"
        )

        return result