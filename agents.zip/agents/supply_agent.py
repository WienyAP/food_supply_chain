import pandas as pd
import numpy as np

from .base_agent import BaseAgent


class SupplyAgent(BaseAgent):

    def __init__(self):
        super().__init__("Supply Agent")

    def run(self, data: pd.DataFrame) -> pd.DataFrame:

        # =========================================================
        # 1. VALIDASI INPUT
        # =========================================================

        required_columns = [
            "year",
            "region",
            "produksi"
        ]

        missing_columns = [
            col
            for col in required_columns
            if col not in data.columns
        ]

        if missing_columns:
            raise ValueError(
                f"Kolom yang diperlukan tidak ditemukan: {missing_columns}"
            )

        # Gunakan hanya kolom yang diperlukan.
        # Data sudah divalidasi oleh preprocessing.py.
        result = data[
            required_columns
        ].copy()

        # =========================================================
        # 2. VALIDASI NILAI
        # =========================================================

        if result[required_columns].isna().any().any():
            raise ValueError(
                "Terdapat missing value pada input Supply Agent."
            )

        if (result["produksi"] < 0).any():
            raise ValueError(
                "Ditemukan nilai produksi negatif."
            )

        if result.duplicated(
            subset=["year", "region"]
        ).any():
            raise ValueError(
                "Terdapat duplikasi year + region."
            )

        # =========================================================
        # 3. CURRENT SUPPLY
        # =========================================================

        result["current_supply"] = result["produksi"]

        # =========================================================
        # 4. RATA-RATA PRODUKSI PER TAHUN
        # =========================================================

        result["rata_produksi_tahun"] = (
            result
            .groupby("year")["produksi"]
            .transform("mean")
        )

        # =========================================================
        # 5. PRODUCTION RATIO
        # =========================================================

        result["production_ratio"] = (
            result["produksi"]
            / result["rata_produksi_tahun"]
        )

        # =========================================================
        # 6. PRODUCTION SHARE
        # =========================================================

        total_produksi_tahun = (
            result
            .groupby("year")["produksi"]
            .transform("sum")
        )

        result["production_share"] = (
            result["produksi"]
            / total_produksi_tahun
        )

        # =========================================================
        # 7. PRODUCTION GROWTH
        # =========================================================

        result = result.sort_values(
            ["region", "year"]
        ).reset_index(drop=True)

        result["production_growth"] = (
            result
            .groupby("region")["produksi"]
            .pct_change()
            * 100
        )

        # =========================================================
        # 8. SUPPLY TREND
        # =========================================================

        def calculate_slope(group):

            if len(group) < 2:
                return 0.0

            x = group["year"].to_numpy(dtype=float)
            y = group["produksi"].to_numpy(dtype=float)

            return float(np.polyfit(x, y, 1)[0])

        trend = (
            result
            .groupby("region")
            .apply(calculate_slope)
            .rename("trend_slope")
            .reset_index()
        )

        result = result.merge(
            trend,
            on="region",
            how="left"
        )

        # =========================================================
        # 9. SUPPLY STATUS
        # =========================================================

        result["supply_status"] = np.select(
            [
                result["production_ratio"] >= 1.20,
                result["production_ratio"] >= 0.80
            ],
            [
                "high",
                "normal"
            ],
            default="low"
        )

        # =========================================================
        # 10. FINAL SORTING
        # =========================================================

        result = result.sort_values(
            ["year", "region"]
        ).reset_index(drop=True)

        return result