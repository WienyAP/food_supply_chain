
import pandas as pd

from .base_agent import BaseAgent


class RecommendationAgent(BaseAgent):
    """Menyusun kandidat distribusi untuk ditinjau, bukan keputusan pengiriman."""

    def __init__(self):
        super().__init__("Recommendation Agent")

    @staticmethod
    def normalize_name(name):
        return " ".join(str(name).strip().casefold().split())

    @staticmethod
    def build_region_lookup(regions):
        """
        Membuat lookup nama wilayah.
        Alias nama pendek hanya dibuat jika unik.
        """
        lookup = {}

        for region in regions:
            full_name = str(region).strip()
            key = RecommendationAgent.normalize_name(full_name)
            lookup.setdefault(key, set()).add(full_name)

        # Alias tanpa awalan hanya jika tidak ambigu.
        prefixes = ("kabupaten ", "kota ")

        for region in regions:
            full_name = str(region).strip()
            key = RecommendationAgent.normalize_name(full_name)

            for prefix in prefixes:
                if key.startswith(prefix):
                    alias = key[len(prefix):].strip()
                    lookup.setdefault(alias, set()).add(full_name)
                    break

        # Hanya alias yang menunjuk tepat satu wilayah yang digunakan.
        return {
            alias: next(iter(matches))
            for alias, matches in lookup.items()
            if len(matches) == 1
        }

    def run(self, supply_demand, distribution):
        required_sd = {
            "year", "region", "produksi", "supply_status"
        }
        required_dist = {
            "Lokasi Asal Pasokan",
            "Lokasi Tujuan Pengiriman",
            "volume_ton",
        }

        missing_sd = required_sd - set(supply_demand.columns)
        missing_dist = required_dist - set(distribution.columns)

        if missing_sd:
            raise ValueError(
                f"Kolom supply-demand tidak tersedia: {sorted(missing_sd)}"
            )

        if missing_dist:
            raise ValueError(
                f"Kolom distribusi tidak tersedia: {sorted(missing_dist)}"
            )

        sd = supply_demand.copy()
        dist = distribution.copy()

        regions = sd["region"].dropna().astype(str).str.strip().unique()
        lookup = self.build_region_lookup(regions)

        # Pemetaan nama lokasi distribusi ke nama standar.
        def map_location(value):
            key = self.normalize_name(value)
            return lookup.get(key)

        dist["origin_standard"] = (
            dist["Lokasi Asal Pasokan"].map(map_location)
        )
        dist["destination_standard"] = (
            dist["Lokasi Tujuan Pengiriman"].map(map_location)
        )

        # Rute yang benar-benar muncul pada catatan distribusi.
        recorded_routes = set(
            zip(
                dist.loc[
                    dist["origin_standard"].notna()
                    & dist["destination_standard"].notna(),
                    "origin_standard",
                ],
                dist.loc[
                    dist["origin_standard"].notna()
                    & dist["destination_standard"].notna(),
                    "destination_standard",
                ],
            )
        )

        latest_year = int(sd["year"].max())
        latest = sd[sd["year"] == latest_year].copy()

        sources = latest[latest["supply_status"] == "high"]
        destinations = latest[latest["supply_status"] == "low"]

        rows = []

        for _, source in sources.iterrows():
            for _, destination in destinations.iterrows():
                origin = str(source["region"]).strip()
                target = str(destination["region"]).strip()

                if origin == target:
                    continue

                route_exists = (origin, target) in recorded_routes

                rows.append({
                    "tahun_acuan_produksi": latest_year,
                    "wilayah_asal_kandidat": origin,
                    "wilayah_tujuan_kandidat": target,
                    "produksi_asal_ton": source["produksi"],
                    "produksi_tujuan_ton": destination["produksi"],
                    "status_produksi_asal": source["supply_status"],
                    "status_produksi_tujuan": destination["supply_status"],
                    "rute_tercatat_dalam_data": route_exists,
                    "status_bukti_rute": (
                        "rute ditemukan"
                        if route_exists
                        else "rute belum terverifikasi"
                    ),
                    "alasan": (
                        "Produksi relatif tinggi ke produksi relatif rendah; "
                        "stok, kebutuhan aktual, dan kelayakan rute "
                        "masih perlu diverifikasi."
                    ),
                    "status_rekomendasi": "kandidat untuk ditinjau",
                })

        return pd.DataFrame(rows)
