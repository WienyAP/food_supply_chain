
import pandas as pd

from .base_agent import BaseAgent


class CoordinatorAgent(BaseAgent):
    """Mengintegrasikan hasil Supply, Demand, dan Distribution Agent."""

    def __init__(self):
        super().__init__("Coordinator Agent")

    @staticmethod
    def _standardize_region(name, demand_regions):
        """Cocokkan nama wilayah tanpa menggabungkan kabupaten dan kota."""
        name = str(name).strip()

        if name in demand_regions:
            return name

        candidate = f"Kabupaten {name}"
        if candidate in demand_regions:
            return candidate

        return None

    def run(self, data: dict) -> dict:
        required_inputs = {
            "supply": ["year", "region", "produksi", "supply_status"],
            "demand": ["region", "konsumsi"],
            "distribution": [
                "Tahun",
                "Lokasi Tujuan Pengiriman",
                "volume_kg",
                "volume_ton",
            ],
        }

        for key in ["supply", "demand", "distribution"]:
            if key not in data:
                raise ValueError(f"Input '{key}' tidak tersedia.")

            if not isinstance(data[key], pd.DataFrame):
                raise TypeError(f"Input '{key}' harus berupa DataFrame.")

            missing = [
                col for col in required_inputs[key]
                if col not in data[key].columns
            ]

            if missing:
                raise ValueError(
                    f"Kolom input '{key}' tidak ditemukan: {missing}"
                )

        supply = data["supply"].copy()
        demand = data["demand"].copy()
        distribution = data["distribution"].copy()

        # Validasi baseline konsumsi.
        demand["region"] = demand["region"].astype(str).str.strip()

        if demand["region"].duplicated().any():
            raise ValueError(
                "Data demand memiliki nama wilayah duplikat."
            )

        demand_regions = set(demand["region"])

        # Standarkan nama wilayah pada data produksi.
        supply["region"] = supply["region"].map(
            lambda name: self._standardize_region(
                name, demand_regions
            )
        )

        if supply["region"].isna().any():
            unmatched = (
                data["supply"]
                .loc[supply["region"].isna(), "region"]
                .drop_duplicates()
                .tolist()
            )
            raise ValueError(
                f"Wilayah produksi belum cocok: {unmatched}"
            )

        # Pastikan tidak ada duplikasi wilayah-tahun.
        if supply.duplicated(["year", "region"]).any():
            raise ValueError(
                "Data supply memiliki duplikasi year + region."
            )

        # Gabungkan produksi dengan baseline konsumsi.
        supply_demand = supply.merge(
            demand,
            on="region",
            how="left",
            validate="many_to_one",
        )

        if supply_demand["konsumsi"].isna().any():
            raise ValueError(
                "Sebagian wilayah belum memiliki baseline konsumsi."
            )

        # Ringkas distribusi berdasarkan tahun dan tujuan.
        distribution["Tahun"] = pd.to_numeric(
            distribution["Tahun"], errors="coerce"
        )

        if distribution["Tahun"].isna().any():
            raise ValueError(
                "Terdapat tahun distribusi yang tidak valid."
            )

        distribution_summary = (
            distribution.groupby(
                ["Tahun", "Lokasi Tujuan Pengiriman"],
                as_index=False,
                dropna=False,
            )
            .agg(
                jumlah_catatan=("volume_kg", "size"),
                volume_masuk_kg=("volume_kg", "sum"),
                volume_masuk_ton=("volume_ton", "sum"),
            )
            .sort_values(
                ["Tahun", "Lokasi Tujuan Pengiriman"]
            )
            .reset_index(drop=True)
        )

        return {
            "supply_demand": supply_demand,
            "distribution_summary": distribution_summary,
        }
