
import pandas as pd

from .base_agent import BaseAgent
from IPython.display import  display


class DistributionAgent(BaseAgent):
    """Mengolah catatan distribusi dan merangkum aliran beras."""

    def __init__(self):
        super().__init__("Distribution Agent")

    def run(self, data: pd.DataFrame) -> pd.DataFrame:
        required = [
            "Tahun",
            "Bulan",
            "Komoditas",
            "Lokasi Asal Pasokan",
            "Provinsi Asal Pasokan",
            "Lokasi Tujuan Pengiriman",
            "Provinsi Tujuan Pengiriman",
            "Volume",
            "Satuan",
        ]

        missing = [col for col in required if col not in data.columns]
        if missing:
            raise ValueError(
                f"Kolom wajib distribusi tidak ditemukan: {missing}"
            )

        
        df = data[required].copy()

        # Rapikan kolom teks.
        text_columns = [
            "Bulan",
            "Komoditas",
            "Lokasi Asal Pasokan",
            "Provinsi Asal Pasokan",
            "Lokasi Tujuan Pengiriman",
            "Provinsi Tujuan Pengiriman",
            "Satuan",
        ]

        for col in text_columns:
            df[col] = df[col].astype("string").str.strip()

        # Filter beras terlebih dahulu.
        df = df[
            df["Komoditas"].str.casefold().eq("beras")
        ].copy()

        if df.empty:
            raise ValueError("Tidak ditemukan catatan distribusi beras.")

        # Baru validasi Tahun dan Volume untuk data beras.
        df["Tahun"] = pd.to_numeric(df["Tahun"], errors="coerce")
        df["Volume"] = pd.to_numeric(df["Volume"], errors="coerce")

        invalid = df["Tahun"].isna() | df["Volume"].isna()

        if invalid.any():
            print("Baris data beras yang tidak valid:")
            display(df.loc[invalid].head(20))
            raise ValueError(
                "Terdapat Tahun atau Volume beras yang kosong/tidak numerik."
            )

        if (df["Volume"] < 0).any():
            raise ValueError("Ditemukan volume distribusi negatif.")

        if not df["Satuan"].str.casefold().eq("kg").all():
            raise ValueError(
                "Volume beras harus menggunakan satuan kg."
            )

        df["volume_kg"] = df["Volume"]
        df["volume_ton"] = df["volume_kg"] / 1000

        df["arus_provinsi"] = (
            df["Provinsi Asal Pasokan"]
            + " -> "
            + df["Provinsi Tujuan Pengiriman"]
        )

        df["jenis_arus"] = (
            df["Provinsi Asal Pasokan"]
            .eq(df["Provinsi Tujuan Pengiriman"])
            .map({
                True: "antarwilayah_dalam_provinsi",
                False: "antarprovinsi",
            })
        )

        return df.reset_index(drop=True)

    @staticmethod
    def summarize_by_route(distribution: pd.DataFrame) -> pd.DataFrame:
        """Jumlahkan volume berdasarkan provinsi asal dan tujuan."""
        summary = (
            distribution.groupby(
                [
                    "Provinsi Asal Pasokan",
                    "Provinsi Tujuan Pengiriman",
                ],
                as_index=False,
                dropna=False,
            )
            .agg(
                jumlah_catatan=("volume_kg", "size"),
                total_volume_kg=("volume_kg", "sum"),
                total_volume_ton=("volume_ton", "sum"),
            )
            .sort_values("total_volume_kg", ascending=False)
            .reset_index(drop=True)
        )

        return summary

    @staticmethod
    def summarize_monthly(distribution: pd.DataFrame) -> pd.DataFrame:
        """Ringkasan volume beras per tahun dan bulan."""
        return (
            distribution.groupby(
                ["Tahun", "Bulan"],
                as_index=False,
                dropna=False,
            )
            .agg(
                jumlah_catatan=("volume_kg", "size"),
                total_volume_kg=("volume_kg", "sum"),
                total_volume_ton=("volume_ton", "sum"),
            )
            .sort_values(["Tahun", "Bulan"])
            .reset_index(drop=True)
        )
